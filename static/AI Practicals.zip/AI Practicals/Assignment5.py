# Design and Implementation of an Interactive Expert System 
# Using Forward Chaining

# Aim:- Develop an interactive expert system to 
# troubleshoot common computer issues

def diagnose_issue():
    print("Welcome to the Computer Troubleshooting Expert System")
    print("Answer the following questions with yes or no")

    power = input("Is your computer turning on? ").lower()
    if power == "no":
        cable = input("Is the power cable properly connected? ").lower()
        if cable == "no":
            print("Connect the power cable properly and try again.")
        else:
            print("Check your power supply or contact a technician.")
        return

    boot = input("Does the computer boot into the operating system? ").lower()
    if boot == "no":
        beep = input("Do you hear any beeping sounds when it starts? ").lower()
        if beep == "yes":
            print("Check the RAM and ensure it is properly seated.")
        else:
            print("Check the hard drive connection or reinstall the OS.")
        return

    slow = input("Is your computer running slow? ").lower()
    if slow == "yes":
        storage = input("Is your storage almost full? ").lower()
        if storage == "yes":
            print("Delete unnecessary files or upgrade your storage.")
        else:
            print("Scan for viruses or consider adding more RAM.")
        return

    internet = input("Are you facing internet connection issues? ").lower()
    if internet == "yes":
        wifi = input("Is your Wi-Fi connected? ").lower()
        if wifi == "no":
            print("Connect to your Wi-Fi network.")
        else:
            print("Restart your router or contact your ISP.")
        return

    print("No major issues detected. Your system seems fine.")

diagnose_issue()
