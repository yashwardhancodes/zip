# Goal Stack Planning in Block World Domain
# Aim:- To implement Goal Stack Planning in Block World Domain

from copy import deepcopy
from collections import deque

def make_state(on_map):
    blocks = set(on_map.keys()) | {v for v in on_map.values() if v != 'table'}
    clear = {b: True for b in blocks}
    for b, support in on_map.items():
        if support != 'table':
            clear[support] = False
    state = {
        'on': dict(on_map),
        'clear': clear,
        'holding': None,
        'handempty': True
    }
    return state

def is_satisfied(state, goal):
    typ = goal[0]
    if typ == 'on':
        _, x, y = goal
        return state['on'].get(x) == y
    if typ == 'ontable':
        _, x = goal
        return state['on'].get(x) == 'table'
    if typ == 'clear':
        _, x = goal
        return state['clear'].get(x, False)
    if typ == 'holding':
        _, x = goal
        return state['holding'] == x
    if typ == 'handempty':
        return state['handempty']
    return False

def applicable(state, action):
    typ = action[0]
    if typ == 'pickup':
        _, x = action
        return state['on'].get(x) == 'table' and state['clear'].get(x, False) and state['handempty']
    if typ == 'putdown':
        _, x = action
        return state['holding'] == x
    if typ == 'stack':
        _, x, y = action
        return state['holding'] == x and state['clear'].get(y, False)
    if typ == 'unstack':
        _, x, y = action
        return state['on'].get(x) == y and state['clear'].get(x, False) and state['handempty']
    return False

def apply_action(state, action):
    s = deepcopy(state)
    typ = action[0]
    if typ == 'pickup':
        _, x = action
        s['on'][x] = None
        s['clear'][x] = False
        s['holding'] = x
        s['handempty'] = False
    elif typ == 'putdown':
        _, x = action
        s['on'][x] = 'table'
        s['clear'][x] = True
        s['holding'] = None
        s['handempty'] = True
    elif typ == 'stack':
        _, x, y = action
        s['on'][x] = y
        s['clear'][x] = True
        s['clear'][y] = False
        s['holding'] = None
        s['handempty'] = True
    elif typ == 'unstack':
        _, x, y = action
        s['on'][x] = None
        s['clear'][x] = False
        s['clear'][y] = True
        s['holding'] = x
        s['handempty'] = False
    return s

def choose_action_for_goal(goal, state):
    typ = goal[0]
    if typ == 'on':
        _, x, y = goal
        if state['on'].get(x) == y:
            return None
        if state['holding'] == x:
            return ('stack', x, y)
        if state['on'].get(x) == 'table' and state['clear'].get(x, False) and state['handempty']:
            return ('pickup', x)
        z = state['on'].get(x)
        if z and z != 'table':
            return ('unstack', x, z)
        return ('pickup', x)
    if typ == 'ontable':
        _, x = goal
        if state['on'].get(x) == 'table':
            return None
        if state['holding'] == x:
            return ('putdown', x)
        z = state['on'].get(x)
        if z and z != 'table':
            return ('unstack', x, z)
        return ('pickup', x)
    if typ == 'clear':
        _, x = goal
        if state['clear'].get(x, False):
            return None
        for b, support in state['on'].items():
            if support == x:
                return ('unstack', b, x)
        return None
    if typ == 'holding':
        _, x = goal
        if state['holding'] == x:
            return None
        if state['on'].get(x) == 'table' and state['clear'].get(x, False) and state['handempty']:
            return ('pickup', x)
        y = state['on'].get(x)
        if y and y != 'table':
            return ('unstack', x, y)
        return ('pickup', x)
    if typ == 'handempty':
        if state['handempty']:
            return None
        if state['holding']:
            return ('putdown', state['holding'])
        return None
    return None

def preconditions(action):
    typ = action[0]
    if typ == 'pickup':
        _, x = action
        return [('ontable', x), ('clear', x), ('handempty',)]
    if typ == 'putdown':
        _, x = action
        return [('holding', x)]
    if typ == 'stack':
        _, x, y = action
        return [('holding', x), ('clear', y)]
    if typ == 'unstack':
        _, x, y = action
        return [('on', x, y), ('clear', x), ('handempty',)]
    return []

def goal_stack_planner(initial_state, goals):
    state = deepcopy(initial_state)
    plan = []
    stack = deque()
    for g in reversed(goals):
        stack.append(g)

    while stack:
        top = stack.pop()
        if isinstance(top, tuple) and top and top[0] in ('on','ontable','clear','holding','handempty'):
            if is_satisfied(state, top):
                continue
            action = choose_action_for_goal(top, state)
            if action is None:
                continue
            stack.append(top)
            stack.append(action)
            for p in reversed(preconditions(action)):
                stack.append(p)
        else:
            action = top
            if action is None:
                continue
            if applicable(state, action):
                plan.append(action)
                state = apply_action(state, action)
            else:

                stack.append(action)
                for p in reversed(preconditions(action)):
                    if not is_satisfied(state, p):
                        stack.append(p)
    return plan, state

def pretty_action(a):
    if a[0] == 'pickup':
        return f"Pickup({a[1]})"
    if a[0] == 'putdown':
        return f"Putdown({a[1]})"
    if a[0] == 'stack':
        return f"Stack({a[1]}, {a[2]})"
    if a[0] == 'unstack':
        return f"Unstack({a[1]}, {a[2]})"
    return str(a)

if __name__ == "__main__":

    on_map = {'A': 'table', 'B': 'table', 'C': 'A'}
    initial = make_state(on_map)
    goals = [('on','C','B'), ('on','B','A')]

    plan, final_state = goal_stack_planner(initial, goals)
    print("Plan found:")
    for i, a in enumerate(plan, 1):
        print(i, pretty_action(a))
    print("\nFinal 'on' relations:")
    for b in sorted(final_state['on'].keys()):
        val = final_state['on'][b] if final_state['on'][b] else 'none'
        print(f"  {b} -> {val}")
