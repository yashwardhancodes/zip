# CSP-based Sports Tournament Scheduling (IPL Example)

# Aim:- To implement Constraint Satisfaction Problem (CSP) for 
# scheduling matches in a sports tournament (IPL example) using Python.

from constraint import Problem, AllDifferentConstraint

problem = Problem()

subjects = {
    "AI": "Prof.Sushant Naik",
    "ML": "Prof.Swarup Magar",
    "DBMS": "Prof.Tejas Pandure",
    "DS": "Prof.Sharma"
}

time_slots = ["Mon_10am", "Tue_10am", "Mon_9am", "Tue_9am"]

problem.addVariables(subjects.keys(), time_slots)

problem.addConstraint(AllDifferentConstraint(), subjects.keys())

problem.addConstraint(lambda t: t != "Mon_9am", ("AI",))

problem.addConstraint(lambda t: t in ["Tue_9am", "Tue_10am"], ("DS",))

solutions = problem.getSolutions()

print("Total possible solutions:", len(solutions))
if solutions:
    print("Sample solution:", solutions[0])
