# A* Algorithm for Optimal Path Finding

# Aim:- To implement the A* (A-Star) algorithm for finding the most 
# cost-effective path in a weighted graph using heuristic values.

graph = {
    'A': {'B': 6, 'F': 3},
    'B': {'C': 3, 'D': 2, 'A': 6},
    'C': {'E': 5, 'D': 1, 'B': 3},
    'D': {'B': 2, 'C': 1, 'E': 8},
    'E': {'C': 5, 'D': 8, 'I': 5, 'J': 5},
    'F': {'A': 3, 'G': 1, 'H': 7},
    'G': {'F': 1, 'I': 3},
    'H': {'F': 7, 'I': 2},
    'I': {'G': 3, 'H': 2, 'E': 5, 'J': 3},
    'J': {'E': 5, 'I': 3}
}

heuristic = {'A':10,'B':8,'C':5,'D':7,'E':3,'F':6,'G':5,'H':3,'I':1,'J':0}

start_node = 'A'
goal_node = 'J'

open=[(start_node,0)]
closed=[]

while open:
    if not open:
        print("Failure")
        exit()

    min_f = float("inf")
    current_node, current_g = None, None
    for node, g in open:
        f = g + heuristic[node]
        if f < min_f:
            min_f = f
            current_node, current_g = node, g

    open.remove((current_node,current_g))
    closed.append(current_node)

    print(f"Current node: {current_node}, g={current_g}, h={heuristic[current_node]}, f={current_g + heuristic[current_node]}")

    if current_node==goal_node:
        print("Reached")
        break

    for neighbor, cost in graph[current_node].items():
        if neighbor not in closed:
            g_cost = current_g + cost
            open.append((neighbor, g_cost)) 

print("Closed List (visited):", closed)
print("Cost:",current_g)
