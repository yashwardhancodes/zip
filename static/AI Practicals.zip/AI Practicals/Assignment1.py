# Breadth First Search (BFS) using Queue on Graph

# Aim:- To implement Breadth First Search (BFS) traversal 
# on a graph using the queue data structure

tree={
    'A':['B','C'],
    'B':['D','E'],
    'C':['F','G'],
    'D':[],
    'E':[],
    'F':[],
    'G':[]
}
q=[]
vis=[]
q.append('A')

while q:
    node=q.pop()
    vis.append(node)

    for ch in tree[node]:
        q.append(ch)

print(vis)